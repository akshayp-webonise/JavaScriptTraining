import path from 'path';
import webpack from 'webpack';
import HtmlWebPackPlugin from 'html-webpack-plugin';

const SRC_DIR = path.resolve(__dirname, 'src');

module.exports = {
  entry: ["./src/index.js"],
  output: {
    path: path.resolve(__dirname, 'dist'),
    filename: 'js/[name]-[hash].js'
  },
  devServer: {
    contentBase: "./dist"
  },  
  module: {
    rules: [
      {
        test: /\.js/,
        exclude: /node_modules/,
        use: {
          loader: 'babel-loader'
        }
      },
      {
        test: /\.html$/,
        use: [
          {
            loader: "html-loader"
          }
        ]
      }      
    ]
  },
  plugins: [
    new HtmlWebPackPlugin({
      template: "./public/index.html",
      filename: "./index.html"
    }),
    new webpack.HotModuleReplacementPlugin(),
    new webpack.ProvidePlugin({
      _: 'underscore'
    })
  ],
  resolve: {
    alias: {
      Components: SRC_DIR + '/js/components',
      JavaScript: SRC_DIR + '/js'
    },
    extensions: ['.js']
  }  
}