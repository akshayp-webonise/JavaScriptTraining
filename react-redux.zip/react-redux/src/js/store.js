import { applyMiddleware, createStore } from 'redux';

// middlewares
import reduxLogger from 'redux-logger';
import reduxThunk from 'redux-thunk';

import reducers from 'JavaScript/reducers';

const middlewares = applyMiddleware(reduxThunk, reduxLogger);

const store = createStore(reducers, middlewares);

export default store;