import React from 'react';
import ReactDOM from 'react-dom';
import Root from './js/routes';

ReactDOM.render(<Root />, document.getElementById('root'));